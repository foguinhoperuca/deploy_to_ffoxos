# JAMES

Your personal assistant.

# Features

* Help you manage your expenses;
* Help you manage your eating habits;
* Help you manage your vehicle;
* Help you manage your workout;
* Help you manage your timesheet;
* Help you buy groceries;

# Credits

Jefferson Campos - 2014 - Mozilla Public License, version 2.0

## Icons

Creative Commons – Attribution (CC BY 3.0)
Waiter by Piotrek Chuchla from The Noun Project
Original was get here: http://thenounproject.com/term/waiter/21573/
