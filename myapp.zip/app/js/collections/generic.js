define([
	'backbone'
], function (Backbone){
	var Collection = Backbone.Collection.extend({
	});

	return Collection;
});
