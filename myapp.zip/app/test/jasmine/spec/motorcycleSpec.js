// define(['../../../../js/app'], function (App) {
define(['app'], function (App) {
	return describe('Motorcycle.', function() {
		it('Should implement test.', function() {
			return true;
		});
	});
});
