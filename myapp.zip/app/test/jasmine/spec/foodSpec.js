// define(['../../../../js/app'], function (App) {
define(['app'], function (App) {
	return describe('Food.', function() {
		it('Should implement test.', function() {
			return true;
		});
	});
});
