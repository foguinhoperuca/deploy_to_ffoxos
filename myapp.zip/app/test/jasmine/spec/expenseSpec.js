// define(['../../../../js/app'], function (App) {
define(['app'], function (App) {
	return describe('Expense.', function() {
		it('Should implement test.', function() {
			return true;
		});
	});
});
