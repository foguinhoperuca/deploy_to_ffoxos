// define(['../../../../js/app'], function (App) {
define(['app'], function (App) {
	return describe('Google Drive.', function() {
		it('Should implement test.', function() {
			return true;
		});
	});
});
